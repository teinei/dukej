var pixelsDone = 0;
var totalPixels = 0; 
var bgImage = null;
var fgImage = null;

function loadForegroundImage(input) {
  fgImage = new SimpleImage(input);
   var can = document.getElementById("fgimage");
  fgImage.drawTo(can);
}

function loadBackgroundImage(input) {
  bgImage = new SimpleImage(input);
  var can = document.getElementById("bgimage");
  bgImage.drawTo(can);
}

function setGreen() {
  // get the range input's current value
  var threshold = document.getElementById("greenInput").value;
  // set new value to display exact value
  document.getElementById("greenOutput").value = threshold;
  // call greenScreen each time to see it update LIVE
  greenScreen();
}

function updateProgress(percent) {
  var prog = document.getElementById("prog");
  prog.value = percent;
  var lab = document.getElementById("plabel");
  lab.innerHTML = percent+"%";
}

function greenScreen() {
  // update images only if they have been loaded
  if (fgImage !== null && fgImage.complete() &&
    bgImage !== null && bgImage.complete() &&
    fgImage.getWidth() == bgImage.getWidth() &&
    fgImage.getHeight() == bgImage.getHeight()) {
    var greenThreshold = 240;
    //clearProgress();
    //document.getElementById('greenInput').value;
    var output = new SimpleImage(fgImage.getWidth(), fgImage.getHeight());

    totalPixels = fgImage.getHeight() * fgImage.getWidth();
    pixelsDone = 0;
    var canvas = document.getElementById("fgimage");
    
    var prog = document.getElementById("prog");
    
    // for each pixel in fgImage 
    console.log("loop start");
    var pixels = fgImage.values();
    var id = setInterval(greenit,10);
  function greenit() { 
      for(var k=0; k < 10000; k++) {
        //console.log("greenit "+pixelsDone);
        if (pixelsDone >= totalPixels) {
          console.log("cleared");
          clearInterval(id);
          clearCanvas();
          output.drawTo(canvas); 
          updateProgress(100);
          break;
        }
        else {

          var pixel = pixels[pixelsDone];
          var percent = Math.floor(100*pixelsDone/totalPixels);
          var old = prog.value;
          pixelsDone++;
          if (percent != old) {
            updateProgress(percent);
            //prog.value = percent;
            console.log("perc: "+percent);
          }
          if (pixel.getGreen() > greenThreshold) {
            var x = pixel.getX();
            var y = pixel.getY();
            var bgPixel = bgImage.getPixel(x, y);
            output.setPixel(x, y, bgPixel);
          }
          // otherwise: set output’s corresponding pixel to current pixel
          else {
            output.setPixel(pixel.getX(), pixel.getY(), pixel);
          }
        }
     }  
    }  
    console.log("pixels "+pixels.length+" "+totalPixels);

    console.log("pixels done "+pixelsDone);
  } else {
    alert("Foreground and Background images must be the same size.");
  }
}
 
function doClear(canvas) {
  var context = canvas.getContext("2d");
  context.clearRect(0, 0, canvas.width, canvas.height);
}

function clearCanvas() {
  var fgcanvas = document.getElementById("fgimage");
  var bgcanvas = document.getElementById("bgimage");

  doClear(fgcanvas);
  doClear(bgcanvas);
  
}
function clearProgess(){
  var prog = document.getElementById("prog");
  prog.value = 0;
  //prog.innerHTML = 0;
}
function allClear() {
  clearCanvas();
  clearProgress();
}