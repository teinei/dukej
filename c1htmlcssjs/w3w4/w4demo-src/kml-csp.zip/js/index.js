function toCSV(list){
  nlist = [];
  for(var i = 0; i < list.length; i++){
    nlist.push(list[i].name+","+list[i].lat+","+list[i].lon);
  }
  return nlist;
}
function extract(str){ 
   
    var data = str.split("\n");
    var outList = [];
    var currentObj;
 
  
    for(var i = 0; i < data.length; i++){ 
      var coordPos = data[i].indexOf("<coordinates>");
	    var namePos = data[i].indexOf("<name>");

	    //Assumption: <name> always comes before <coordinates>
	    if(namePos >=0){
	      currentObj = {};   //new name means we have a new record
	      currentObj.name = data[i].substring(namePos+6, data[i].indexOf("</name>"));
	    }
	    if(coordPos >=0){
	      var temp = data[i+1].trim().split(',');
	      currentObj.lon = temp[0];
	      currentObj.lat = temp[1];
	      outList.push(currentObj);  
      }
      coordPos = -1;
      namePos = -1;
    }
    return outList;
}

function processkml() {
    var txt = document.getElementById("txt");
    var display = document.getElementById("csv");  
    var str = txt.value;
    display.value = "hello world";
    //display.value = str;
    var list = extract(str);
    console.log("final "+list.length);
    //alert("this is "+list[0]);
    var nlist = toCSV(list);
    display.value = nlist.join('\n');
}