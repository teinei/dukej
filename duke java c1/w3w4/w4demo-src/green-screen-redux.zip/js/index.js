var bgImage = null;
var fgImage = null;
var greenThreshold = 240;

function loadForegroundImage() {
   var img = document.getElementById("fg");
   fgImage = new SimpleImage(img);
   var can = document.getElementById("fgimage");
  fgImage.drawTo(can);
}

function loadBackgroundImage() {
  var img = document.getElementById("bg");
  bgImage = new SimpleImage(img);
  var can = document.getElementById("bgimage");
  bgImage.drawTo(can);
}



function greenScreen() {
  // update images only if they have been loaded
  if (fgImage == null || ! fgImage.complete()){
    alert("foreground not loaded");
    return;
  }
  if (bgImage == null || ! bgImage.complete()){
    alert("background not loaded");
  }
  clearCanvas();
  var output = 
        new SimpleImage(fgImage.getWidth(),
                        fgImage.getHeight());
   for(var pixel of fgImage.pixels()) {
      var x = pixel.getX();
      var y = pixel.getY();
      if (pixel.getGreen() > greenThreshold) {
          var bgPixel = bgImage.getPixel(x, y);
          output.setPixel(x, y, bgPixel);
       }
       else {
           output.setPixel(x,y,pixel);
       }
   }
   var canvas = document.getElementById("fgimage");
   output.drawTo(canvas);
}
 
function doClear(canvas) {
  var context = canvas.getContext("2d");
  context.clearRect(0, 0, canvas.width,
                    canvas.height);
}

function clearCanvas() {
  var fgcanvas = document.getElementById("fgimage");
  var bgcanvas = document.getElementById("bgimage");

  doClear(fgcanvas);
  doClear(bgcanvas);
  
}