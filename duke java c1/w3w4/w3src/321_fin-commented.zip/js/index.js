var image=null;
var canvas = null;
var finput=null;//file input
function upload(){
  finput = document.getElementById("fid");
  //get file input element by its id
  canvas = document.getElementById("can");
  //get canvas element by its id
  image = new SimpleImage(finput);//
  //create simple image variable, from html input itself
  //---------------
  //bug code: 
  //image = new SimpleImage("a");
  
  image.drawTo(can);
  //display image
}
//choose file
//upload
//display